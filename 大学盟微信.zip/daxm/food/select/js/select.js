
 $(document).ready(function(){
	  var de_total,dc_totalnum;
	   de_total=dc_totalnum=0;
	$(".dc_add").click(function(){
		var dc_perprice,dc_pnum,dc_ptotal;
		dc_perprice=dc_pnum=dc_ptotal=0;
		dc_pnum=$(this).parent('div').children('.dc_number').val();
  		dc_perprice=$(this).parents('.rt-li').find('.price').text();
		dc_pnum++;
		dc_totalnum++;
		de_total+=(dc_perprice*1);	
		$(this).parent('div').children('.dc_number').val(dc_pnum);
		$('#dc_totalnumber').text(dc_totalnum);
		$('#dc_totalprice').text(de_total);
	});
	$('.dc_move').click(function(){
		var dc_perprice,dc_pnum,dc_ptotal;
		dc_perprice=dc_pnum=dc_ptotal=0;
		dc_pnum=$(this).parent('.number').children('.dc_number').val();
		dc_perprice=$(this).parent('.rt-li').find('.price').text();
		if(dc_pnum>=1){
		dc_pnum--;
		dc_totalnum--;
		de_total-=(dc_perprice*1);
		$(this).parent('.number').children('.dc_number').val(dc_pnum);
		$('#dc_totalnumber').text(dc_totalnum);
		$('#dc_totalprice').text(de_total);
		}
	});
});
   function show(ct,i)
   {
	   document.getElementById(ct+i).style.display="block";
};

function Close(ct,i)
{
	document.getElementById(ct+i).style.display="none";
};