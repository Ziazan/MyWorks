// JavaScript Document
document.writeln("<div class=\"bottom\">");
document.writeln("      <span>COPRIGHT &copy; 2014 ALL RIGHTS RESERVED.武汉科技大学计算机科学与技术学院<br>");
document.writeln("POWERED BY 领航工作室</span>");
document.writeln("</div>");